
if verLessThan('matlab','7.14')
    error('Fail to use PlatEMO since the version for MATLAB is lower than R2012a. Please update your MATLAB software.');
else
    
    
    list1={'ZDT1','ZDT2','ZDT3','ZDT4','ZDT6','DTLZ1','DTLZ2','DTLZ3','DTLZ4','DTLZ5','DTLZ6','DTLZ7'};
    num1= [ 30000  30000  30000  30000  30000  30000   30000   100000  30000   30000   30000   30000 ];
    n1=[100 100 100 100 100 105  105 105 105 105 105 105];
    list2={'BT1','BT2','BT3','BT4','BT5'};
    num2= [ 120000  120000  120000  120000  120000];
    n2=[100 100 100 100 100];
    
    
    list3={'IDTLZ1','IDTLZ2'};
    num3= [ 30000  30000 ];
    n3=[105 105];
    
    
    list=[ list1  list2 list3];
    num=[num1 num2 num3];
    n=[n1 n2 n3];
    for k=1:length(list)
        
        for i=1:100
            
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@NSGAII,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@HCPMOEA,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@SPEA2,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@MOEAD,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@IBEA,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@CMOPSO,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@PICEAg,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@hpaEA,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@CAMOEA,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@GDE3,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@BCEIBEA,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@BiGE,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@TwoREA,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@GFMMOEA,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            
            rand('seed',i);
            randn('seed',i);
            platemo('algorithm',@MSEA,'problem', str2func(char(list(k))),'save',1,'run',i,'N',n(k),'maxFE',num(k))
            
        end
        
    end
end
