function Offspring = OperDE(Parent,Parameter)
%OperatorDE - The operator of differential evolution.
%
%   Off = OperatorDE(P1,P2,P3) uses the operator of differential evolution
%
%   to generate offsprings based on the parents P1, P2, and P3. If P1, P2,
%   and P3 are arrays of SOLUTION objects, then Off is also an array of
%   SOLUTION objects; while if P1, P2, and P3 are matrices of decision
%   variables, then Off is also a matrix of decision variables, i.e., the
%   offsprings are not evaluated. Each object or row of P1, P2, and P3 is
%   used to generate one offspring by P1 + 0.5*(P2-P3) and polynomial
%   mutation.
%
%	Off = OperatorDE(P1,P2,P3,{CR,F,proM,disM}) specifies the parameters of
%	operators, where CR and F are the parameters in differental evolution,
%	proM is the expectation of the number of mutated variables, and disM is
%	the distribution index of polynomial mutation.
%
%   Example:
%       Off = OperatorDE(Parent1,Parent2,Parent3)
%       Off = OperatorDE(Parent1.decs,Parent2.decs,Parent3.decs,{1,0.5,1,20})

%------------------------------- Reference --------------------------------
% H. Li and Q. Zhang, Multiobjective optimization problems with complicated
% Pareto sets, MOEA/D and NSGA-II, IEEE Transactions on Evolutionary
% Computation, 2009, 13(2): 284-302.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2021 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

%% Parameter setting
if nargin > 1
    [CR,F,proM,disM] = deal(Parameter{:});
else
    [CR,F,proM,disM] = deal(1,0.5,1,20);
end
if isa(Parent ,'SOLUTION')
    calObj  = true;
    Parent  = Parent.decs;
else
    calObj = false;
end
[N,D]   = size(Parent);
Problem = PROBLEM.Current();

max_range=repmat(Problem.upper,N,1);
min_range=repmat(Problem.lower,N,1);

% Cosine   =1 - pdist2(Parent,Parent,'cosine');
% [~,cosinesort] = sort(Cosine,2,'descend' );
% cosinesort=cosinesort(:,2:21);
% [~,ind]=sort(rand(size(cosinesort,1),size(cosinesort,2)),2);

% [~,ind]=sort(rand(N,N),2);
% [~,ind]=sort(ind,2);

% ind=ind(:,1:2);
% mutation = Parent + F*(Parent(ind(:,1),:)-Parent(ind(:,2),:));
% temp = rand(N,D);
% randCR = ((temp==max(temp,[],2))+(rand(N,D)<=CR))>=1;
% crossover = randCR.* mutation + (1 - randCR).* Parent;
% ind = (max_range>crossover)&(crossover>min_range);
% Offspring = crossover.* ind +   max_range.* (max_range<crossover) + min_range.*(crossover<min_range);


max_range=Problem.upper;
min_range=Problem.lower;
for i = 1:N
    
    rndsort = setdiff(randperm(N),i,'stable'); %产生没有i的  1:popsize  的乱序数列
    
    rd = rndsort(1);
    rb = rndsort(2);
    rc = rndsort(3);
%     rd=rndsort(1);
%     rb=ind(rndsort(1),1);
%     rc=ind(rndsort(1),2);
    jr = randi([1,D]);
    %下面这个就是差分进化算子，原理简单
    for k = 1:D
        %通过交叉操作使子代至少有一个维度上的值与父代相同
        if rand<=CR || k==jr
            diff = F * (Parent(rb,k) - Parent(rc,k));
            Offspring(i,k) = Parent(rd,k) + diff;
        else
            Offspring(i,k) = Parent(i,k);
        end
    end
    %这里是处理变量范围越界的问题，和粒子群算法中方法类似
    for k = 1:D
        if Offspring(i,k) > max_range(k)
            Offspring(i,k) = max_range(k);
        end
        if Offspring(i,k) < min_range(k)
            Offspring(i,k) = min_range(k);
        end
    end
end

%% Differental evolution
%     Site = rand(N,D) < CR;
%     Offspring       = Parent1;
%     Offspring(Site) = 1*Offspring(Site) + F*(Parent2(Site)-Parent3(Site));
%
    %% Polynomial mutation
    Lower = repmat(Problem.lower,N,1);
    Upper = repmat(Problem.upper,N,1);
    Site  = rand(N,D) < proM/D;
    mu    = rand(N,D);
    temp  = Site & mu<=0.5;
    Offspring       = min(max(Offspring,Lower),Upper);
    Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                      (1-(Offspring(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
    temp = Site & mu>0.5;
    Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                      (1-(Upper(temp)-Offspring(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
if calObj
    Offspring = SOLUTION(Offspring);
end
end