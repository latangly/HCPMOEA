classdef TwoREA < ALGORITHM
 % <multi/many> <real/binary/permutation>
    % <algorithm> <A-G>
    % A Many-Objective Evolutionary Algorithm Based On A Two-Round-Selection Strategy
%     Population   = Global.Initialization();
%     [z,znad]     = deal(min(Population.objs),max(Population.objs));
%     %% Optimization
%     while Global.NotTermination(Population)
%         Lp= Shape_Estimate(Population,Global.N,z,znad)
%         MatingPool=MatingSelection(Population.objs,Global.N,Lp,z,znad);
%         Offspring  = GA(Population(MatingPool));
%         [Population,z,znad] = EnvironmentalSelection([Population,Offspring],Global.N,Lp);
%     end
    
    
    methods
        function main(Algorithm,Problem)
            %% Generate random population
            Population = Problem.Initialization();
%             [~,FrontNo,CrowdDis] = EnvironmentalSelection(Population,Problem.N);
            [z,znad] = deal(min(Population.objs),max(Population.objs));
            
            %% Optimization
            while Algorithm.NotTerminated(Population)
                Lp = Shape_Estimate(Population,Problem.N,z,znad);
                MatingPool=MatingSelection(Population.objs,Problem.N,Lp,z,znad);
                Offspring  = OperatorGA(Population(MatingPool));
%                 NRSPop = dealNRS(Population);
                [Population,z,znad] = EnvironmentalSelection([Population,Offspring],Problem.N,Lp);
            end
        end
    end
end