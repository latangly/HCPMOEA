function Parent = competition(Parent1,Parent2)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
%         Parent1obj = Parent1.objs;
%         Parent2obj = Parent2.objs;
%         Parent2 = Parent2.decs;
%         winner = 0*Parent1.decs;
%         for i=1:size(Parent1obj,1)
%             c1 = dot(Parent1obj(i,:),Parent2obj(i,:))/(norm(Parent1obj(i,:))*norm(Parent2obj(i,:)));
%             c2 = dot(Parent1obj(i,:),Parent2obj(0.5*end+i,:))/(norm(Parent1obj(i,:))*norm(Parent2obj(0.5*end+i,:)));
%             angle1 = rad2deg(acos(c1));
%             angle2 = rad2deg(acos(c2));
%             mask   = (angle1 > angle2);
%             winner(i,:) = ~mask.*Parent2(i,:) + mask.*Parent2(0.5*end+i,:);
%         end
%         Parent = winner;

        Parent = Parent1;
        N=length(Parent1);
        for i = 1:N
            competor = Parent2(randperm(length(Parent2),2));
            c1 = dot(Parent1(i).obj,competor(1).obj)/(norm(Parent1(i).obj)*norm(competor(1).obj));
            c2 = dot(Parent1(i).obj,competor(2).obj)/(norm(Parent1(i).obj)*norm(competor(2).obj));
            angle1 = rad2deg(acos(c1));
            angle2 = rad2deg(acos(c2));
            if angle1<angle2
                Parent(i)=competor(1);
            else
                Parent(i)=competor(2);
            end
        end

end

