function Next = updateNext(Next,ind)
tempind = zeros(1,length(ind));
cumsumNext = cumsum(Next);
for i = 1:length(ind)
    tempind(i) = find(cumsumNext==ind(i),1,'first');
    Next(tempind(i)) = false;
end
end

