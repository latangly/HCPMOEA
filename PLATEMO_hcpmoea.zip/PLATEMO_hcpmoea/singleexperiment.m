if verLessThan('matlab','7.14')
    error('Fail to use PlatEMO since the version for MATLAB is lower than R2012a. Please update your MATLAB software.');
else
    platemo('algorithm',@HCPMOEA,'problem', @ZDT4,'save',0,'N',100,'maxFE',30000)
end